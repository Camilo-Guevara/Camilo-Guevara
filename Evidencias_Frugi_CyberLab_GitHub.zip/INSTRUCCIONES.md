# Incorporación de fotos a GitHub

Repositorio: https://github.com/Camilo-Guevara/Camilo-Guevara
Rama: docs/frugi-cyberlab-2026-10-16
PR: https://github.com/Camilo-Guevara/Camilo-Guevara/pull/1

Este ZIP contiene archivos para agregar a la rama del PR, respetando la estructura de carpetas. Sube las dos carpetas `proyectos/frugi-app/evidencias` y `proyectos/cyberlab/evidencias` manteniendo los nombres y rutas.

PRECAUCIÓN: las imágenes de Frugi provienen de un trabajo en equipo. Confirma permiso del equipo y revisa que no incluyan información que prefieras no hacer pública. Los documentos originales no se publican.

Las capturas CyberLab corresponden a prácticas documentadas, no a comprobaciones del estado actual.
